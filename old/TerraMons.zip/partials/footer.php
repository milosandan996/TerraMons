
<footer>
    <div class="container d-flex justify-content-between align-items-center">
        <a href="index.php">
            <img src="logo.png" style="height: 80px; width: 150px;"  alt="Slika nije ucitana"/>  
        </a>
        <div>
            <p>Copyright © TERRA MONS  – <?php echo date('Y') ?></p>
        </div>
    </div>
</footer>


<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
<script src="js/main.js" type="text/javascript"></script>



<!--font awesome icons-->
<script src="https://kit.fontawesome.com/af4151337a.js" crossorigin="anonymous"></script>
</body>
</html>
