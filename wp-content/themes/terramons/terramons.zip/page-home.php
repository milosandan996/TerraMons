<?php
/*
 * Template Name: Home
 * 
 */

@include 'frontend/partials/header2.php';
?>
<main>
    <section id="lead-section" class="vh-100" style="background-image: linear-gradient(to bottom, rgba(200,178,115,0.5),rgba(0,0,0,0.5)), url(<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/dnevna5.jpg)">
        <div>
            <h1 class="animation" data-animation="slideDown">
                WELCOME
            </h1>
        </div>
    </section>

    <?php
    @include 'frontend/partials/carousel.php';
    ?>


    <section id="frontpage-section2">
        <div class="container">
            <h2>TERRA MONS - APARTMENTS</h2>
            <div class="row  text-justify justify-content-around">
                <div class="col-12 col-md-8">
                    <p class="mb-5">
                        Master apartment in Zlatibor, in the latest
                        "Villa Peković Blue", just a minute's walk from
                        Zlatibor Lake and the very center of the tourist 
                        resort, as well as popular tourist attractions of 
                        this mountain such as ski resorts, hiking and biking
                        trails, traditional restaurants, and other landmarks.
                    </p>
                    <p class="mb-5">
                        This is a place where you can spend time as you wish, 
                        for relaxation, business activities, family or social 
                        gatherings, a place of peace and activity in a 
                        comfortable and modern atmosphere. The apartment 
                        has a living room with a dining area, 2 bedrooms, and a terrace.
                    </p>
                    <p class="mb-5">
                        Our apartment has everything you need for a short
                        or long stay, including bedding, towels, and a fully
                        equipped kitchen with the highest quality cutlery 
                        and appliances such as a kettle, coffee maker, 
                        popcorn maker, citrus juicer, pancake maker, etc.                    
                    </p>
                </div>

            </div>


            <div class="text-center player mb-5">
                <video id="player" autoplay loop muted controls >
                    <source src="<?php echo get_template_directory_uri(); ?>/frontend/images/vid1.mp4" type="video/mp4">
                </video>
            </div>



            <div class="row text-justify justify-content-around">

                <div class="col-12 col-md-8">

                    <p>
                        The living and sleeping areas are done in a mix of
                        attractive and boho style, with refined contrasts
                        in relation to the glass surfaces that surround the
                        entire interior. The apartment is dominated by 
                        various shades and textures of brown color, made
                        of high-quality oak wood material. Glass elements
                        placed over each TV give the space layers and 
                        reflections, so together with the LED elements that
                        dominate throughout the apartment, they make the 
                        entire ambiance luxurious and well-lit. We wanted
                        to bring in a modern element but also to retain 
                        the spirit of tradition and wooden elements that 
                        adorn the Zlatibor mountain. Modern furniture, 
                        pared-down lines, and pronounced contrasts make 
                        this apartment attractive and bold, while also 
                        being adaptive to the location.
                    </p>

                </div>
            </div>
        </div>
    </section>

    <div class="jumbotron text-center" style="margin-bottom:  60px !important; margin-top:  60px !important;">
        <a style="padding: 40px;" class="btn-danger" href="https://terramons.rs/booking/">"ONLINE" REZERVACIJA</a>
    </div>


    <?php
    @include 'frontend/partials/contact-section2.php';
    ?>
</main>
<?php
@include 'frontend/partials/footer.php';
?>