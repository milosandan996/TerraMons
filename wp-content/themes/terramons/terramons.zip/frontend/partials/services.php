
<?php
@include 'partials/header.php';
?>

<main>
    <?php
    @include 'partials/lead-section.php';
    ?>
    
    
    
    <?php
    @include 'partials/contact-section.php';
    ?>
</main>

<?php
@include 'partials/footer.php';
?>