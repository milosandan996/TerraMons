

<div class="honeycomb mt-5" lang="es">

    <!--                           Dnevna soba                               -->

    <a class="honeycomb-cell" href="../images/gallery/dnevna2.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna2.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/dnevna3.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna3.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/dnevna4.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna4.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/dnevna5.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna5.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/dnevna6.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna6.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/dnevna7.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna7.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/dnevna8.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna8.jpg">
    </a>
    <!--                               Kuhinja                                -->

    <a class="honeycomb-cell" href="../images/gallery/dnevna1.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/dnevna1.jpg">
    </a>

    <!--                               Terasa                                -->

    <a class="honeycomb-cell" href="../images/gallery/terasa1.jpg" data-fancybox="gallery1" >
        <img class="honeycomb-cell__image" src="../images/gallery/terasa1.jpg">
    </a>

    <a class="honeycomb-cell honeycomb__placeholder"></a>
</div>

<div class="honeycomb" lang="es">

    <!--                           Spavaca soba                              -->

    <a class="honeycomb-cell" href="../images/gallery/spavaca1.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca1.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca2.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca2.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca3.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca3.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca4.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca4.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca5.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca5.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery17.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery17.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery25.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery25.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca6.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca6.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca7.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca7.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca8.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca8.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/spavaca9.jpg" data-fancybox="gallery2" >
        <img class="honeycomb-cell__image" src="../images/gallery/spavaca9.jpg">
    </a>

    <a class="honeycomb-cell honeycomb__placeholder"></a>
</div>

<div class="honeycomb" lang="es">

    <!--                           Mala soba                               -->

    <a class="honeycomb-cell" href="../images/gallery/mala1.jpg" data-fancybox="gallery3" >
        <img class="honeycomb-cell__image" src="../images/gallery/mala1.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery22.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery22.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/mala2.jpg" data-fancybox="gallery3" >
        <img class="honeycomb-cell__image" src="../images/gallery/mala2.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/mala4.jpg" data-fancybox="gallery3" >
        <img class="honeycomb-cell__image" src="../images/gallery/mala4.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery10.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery10.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery1.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery1.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/mala6.jpg" data-fancybox="gallery3" >
        <img class="honeycomb-cell__image" src="../images/gallery/mala6.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery5.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery5.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/mala7.jpg" data-fancybox="gallery3" >
        <img class="honeycomb-cell__image" src="../images/gallery/mala7.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/mala8.jpg" data-fancybox="gallery3" >
        <img class="honeycomb-cell__image" src="../images/gallery/mala8.jpg">
    </a>

    <a class="honeycomb-cell honeycomb__placeholder"></a>
</div>


<div class="honeycomb" lang="es">

    <!--                           WC i hodnik                               -->


    <a class="honeycomb-cell" href="../images/gallery/gallery13.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery13.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery14.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery14.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery15.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery15.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery26.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery26.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery7.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery7.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery2.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery2.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery3.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery3.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery4.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery4.jpg">
    </a>
    <a class="honeycomb-cell" href="../images/gallery/gallery6.jpg" data-fancybox="gallery4" >
        <img class="honeycomb-cell__image" src="../images/gallery/gallery6.jpg">
    </a>

    <a class="honeycomb-cell honeycomb__placeholder"></a>
</div>


