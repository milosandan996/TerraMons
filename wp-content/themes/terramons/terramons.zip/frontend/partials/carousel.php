
<section id="section-carousel">
    <div class="container">
        <div class="owl-carousel">
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car8.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car1.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car2.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car3.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car4.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car5.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car6.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/carousell/car7.jpg" alt="Slika nije ucitana"/>
            </li>


            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/gallery13.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/gallery14.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/mala2.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/mala4.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/mala8.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/spavaca1.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/terasa1.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/frontend/images/gallery/dnevna6.jpg" alt="Slika nije ucitana"/>
            </li>

        </div>
    </div>
</section>