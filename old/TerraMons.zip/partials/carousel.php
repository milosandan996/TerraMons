


<section id="section-carousel">
    <div class="container">
        <div class="owl-carousel">
            <li>
                <img src="images/carousell/car8.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car1.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car2.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car3.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car4.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car5.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car6.jpg" alt="Slika nije ucitana"/>
            </li>
            <li>
                <img src="images/carousell/car7.jpg" alt="Slika nije ucitana"/>
            </li>
        </div>
    </div>
</section>